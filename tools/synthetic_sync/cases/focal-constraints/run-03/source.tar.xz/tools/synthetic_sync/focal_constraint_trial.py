"""Ledgered public point-FOV trials on frozen plane and mirror cases.

Every actual inner Sync and bundle call is reserved separately. Run this via
an outer process timeout (for example, ``gtimeout 720 python3 -m ...``).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import tarfile
from unittest import mock

from .budget import ExperimentBudget
from .focal_constraints import CASE_NAMES, ROOT as CASE_ROOT, assess, validate
from .solver import calibration, environment, load_core, result_record, solver_arguments


ROOT = Path(__file__).resolve().parents[2]
SOURCE_PATHS = tuple(sorted(
    [*(path.relative_to(ROOT) for path in (ROOT / "core").glob("**/*.py")),
     Path("tools/synthetic_sync/focal_constraints.py"),
     Path("tools/synthetic_sync/focal_constraint_trial.py"),
     Path("tools/synthetic_sync/solver.py"),
     Path("tools/synthetic_sync/budget.py")]
))
SYNC_LIMITS = dict(max_calls=12, per_call_seconds=120, wall_seconds=600)
BUNDLE_LIMITS = dict(max_calls=18, per_call_seconds=30, wall_seconds=540)
INITIAL_CASES = (
    "free-hard", "free-hard-removed", "axis-hard", "axis-hard-removed",
    "mirror-hard-offcenter", "mirror-through-anchor", "mirror-removed",
)


def _finite_json(value):
    if isinstance(value, dict):
        return {key: _finite_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_finite_json(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _source_hash() -> str:
    digest = hashlib.sha256()
    for relative in SOURCE_PATHS:
        digest.update(str(relative).encode())
        digest.update((ROOT / relative).read_bytes())
    return digest.hexdigest()


def _prepare_output(out: Path) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    source_sha256 = _source_hash()
    metadata = dict(source_sha256=source_sha256, environment=environment(ROOT),
                    sync_limits=SYNC_LIMITS, bundle_limits=BUNDLE_LIMITS,
                    case_schema=1)
    manifest = out / "source-runtime.json"
    if manifest.exists():
        if json.loads(manifest.read_text()) != metadata:
            raise ValueError("Trial source/runtime changed; start a new output directory")
    else:
        manifest.write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")
        with tarfile.open(out / "source.tar.xz", "w:xz") as archive:
            for relative in SOURCE_PATHS:
                archive.add(ROOT / relative, arcname=str(relative))
    return metadata


def _outcome_record(outcome, request_cameras: list[dict]) -> dict:
    if not outcome.accepted or outcome.sync_result is None:
        return dict(accepted=False, reason=outcome.reason,
                    initial_rmse_px=(outcome.initial_rmse_px if
                                     outcome.initial_rmse_px < float("inf") else None),
                    fitted_rmse_px=(outcome.fitted_rmse_px if
                                    outcome.fitted_rmse_px < float("inf") else None))
    cameras = []
    for camera in request_cameras:
        updated = dict(camera)
        k = outcome.calibrations[camera["id"]].intrinsics
        updated.update(fx=float(k.fx), fy=float(k.fy))
        cameras.append(updated)
    return dict(accepted=True, reason="", intervals_px=outcome.intervals_px,
                initial_rmse_px=outcome.initial_rmse_px,
                fitted_rmse_px=outcome.fitted_rmse_px,
                fitted=result_record(outcome.sync_result, cameras))


def run(out: Path, names: tuple[str, ...], *, stop_on_positive_failure: bool = True) -> None:
    """Replay named cases in order, with no unreserved numerical attempts."""
    if any(name not in CASE_NAMES for name in names):
        raise ValueError("Unknown focal constraint case")
    metadata = _prepare_output(out)
    _core, sync = load_core()
    from match_perspective.core import lens_refine

    original_sync = lens_refine._run_sync
    original_bundle = lens_refine.fit_independent_focals
    with (ExperimentBudget(out / "sync-ledger.jsonl", metadata=metadata, **SYNC_LIMITS) as sync_budget,
          ExperimentBudget(out / "bundle-ledger.jsonl", metadata=metadata, **BUNDLE_LIMITS) as bundle_budget):
        for name in names:
            case = json.loads((CASE_ROOT / f"{name}.json").read_text())
            validate(case)
            request = case["request"]
            arguments = solver_arguments(request)
            match_inputs = []
            for camera in request["cameras"]:
                cal = calibration(camera)
                match_inputs.append(lens_refine.MatchLensInput(
                    camera["id"], {}, cal.intrinsics,
                    base_calibration=cal, freeze_focal=False))

            def ledgered_sync(*args, **kwargs):
                with sync_budget.attempt(f"{name}:inner-sync", request) as attempt:
                    result = original_sync(*args, **kwargs)
                    attempt.complete(_finite_json(result_record(result, request["cameras"])))
                return result

            def ledgered_bundle(*args, **kwargs):
                initial = args[2]
                trial_input = dict(request=request,
                                   initial=result_record(initial, request["cameras"]),
                                   pick_sigma_px=case["pick_sigma_px"])
                with bundle_budget.attempt(f"{name}:joint-bundle", trial_input) as attempt:
                    outcome = original_bundle(*args, **kwargs)
                    attempt.complete(_finite_json(_outcome_record(outcome, request["cameras"])))
                return outcome

            with (mock.patch.object(lens_refine, "_run_sync", side_effect=ledgered_sync),
                  mock.patch.object(lens_refine, "fit_independent_focals", side_effect=ledgered_bundle)):
                result = lens_refine.refine_lenses_from_landmarks(
                    match_inputs, arguments["observations"], anchor_id=request["anchor_id"],
                    share_lens=False, estimate_focal_from_points=True,
                    pick_sigma_px=case["pick_sigma_px"], fx_span=0.4,
                    plane_groups=arguments["plane_groups"], plane_slack=arguments["plane_slack"],
                    mirror_pairs=arguments["mirror_pairs"], mirror_plane=arguments["mirror_plane"],
                    mirror_slack=arguments["mirror_slack"])
            accepted = bool(result.improved and not result.refusal_reason)
            summary = dict(name=name, accepted=accepted, message=result.message,
                           behavior=case["expectation"]["behavior"],
                           initial_sync_success=bool(result.sync_result.success),
                           initial_cost=result.initial_cost, final_cost=result.final_cost)
            if accepted:
                fitted_cameras = []
                for camera in request["cameras"]:
                    updated = dict(camera)
                    updated.update(fx=result.calibrations[camera["id"]].intrinsics.fx,
                                   fy=result.calibrations[camera["id"]].intrinsics.fy)
                    fitted_cameras.append(updated)
                record = result_record(result.sync_result, fitted_cameras)
                summary["independent"] = assess(case, dict(
                    cameras=record["cameras"], landmarks=record["landmarks"]))
            (out / f"{name}-summary.json").write_text(
                json.dumps(_finite_json(summary), indent=2, sort_keys=True, allow_nan=False) + "\n")
            print(json.dumps(_finite_json(summary), sort_keys=True), flush=True)
            if stop_on_positive_failure and not accepted and case["expectation"]["behavior"] == "reference_geometry":
                break


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("out", type=Path)
    parser.add_argument("--cases", nargs="+", choices=CASE_NAMES, default=INITIAL_CASES)
    parser.add_argument("--continue-on-failure", action="store_true")
    options = parser.parse_args()
    run(options.out, tuple(options.cases), stop_on_positive_failure=not options.continue_on_failure)
