"""Bounded replay of incomplete and imperfect point-FOV picks from saved starts.

The fitter only sees the request and saved Sync state. Independent truth is
evaluated after each decision has been committed to the experiment ledger.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "tests")]
from tools.synthetic_sync.budget import ExperimentBudget
from tools.synthetic_sync.no_vp_bootstrap import assess
from tools.synthetic_sync.solver import environment, load_core, result_record

load_core()
from test_focal_bundle import _inputs
from match_perspective.core import geometry, sync
from match_perspective.core.focal_bundle import fit_independent_focals

SOURCES = ("core/focal_bundle.py", "core/lens_refine.py",
           "tools/synthetic_sync/independent_focal_reliability.py")
FROZEN = ROOT / "tools/synthetic_sync/cases/independent-focal-production"


def _subset(case, size, mode):
    observations = case["request"]["observations"]
    by_point = {}
    for item in observations:
        by_point.setdefault(item["landmark_id"], []).append(item)
    # The middle camera sees all points. Build compact or spread subsets from
    # its raw picks, while preferring three-view overlap to preserve eligibility.
    centers = {key: np.mean([[o["u"], o["v"]] for o in obs], axis=0)
               for key, obs in by_point.items()}
    keys = sorted(by_point)
    if mode == "cluster":
        image_center = np.mean(list(centers.values()), axis=0)
        keys.sort(key=lambda key: (np.linalg.norm(centers[key] - image_center), key))
    else:
        chosen = [min(keys)]
        while len(chosen) < len(keys):
            nxt = max((key for key in keys if key not in chosen),
                      key=lambda key: (min(np.linalg.norm(centers[key] - centers[old])
                                           for old in chosen), key))
            chosen.append(nxt)
        keys = chosen
    selected = set(keys[:size])
    request = deepcopy(case["request"])
    request["points"] = [p for p in request["points"] if p["id"] in selected]
    request["observations"] = [o for o in observations if o["landmark_id"] in selected]
    return request


def _trials():
    # Freeze this short representative matrix before fitting. Exact and noisy
    # controls share underlying geometry; full and partial views are paired.
    for name, size, mode, change in (
        ("no-vp-mixed-guessedK", 8, "spread", "none"),
        ("no-vp-mixed-guessedK", 12, "spread", "none"),
        ("no-vp-mixed-guessedK", 16, "spread", "none"),
        ("no-vp-mixed-guessedK", 23, "spread", "none"),
        ("noisy-mixed", 12, "spread", "none"),
        ("noisy-mixed", 16, "spread", "none"),
        ("noisy-mixed", 23, "spread", "none"),
        ("noisy-shared", 16, "spread", "none"),
        ("noisy-shared", 23, "spread", "none"),
        ("four-view", 12, "spread", "none"),
        ("four-view", 16, "spread", "none"),
        ("noisy-mixed", 16, "cluster", "none"),
        ("noisy-mixed", 23, "spread", "bad_pick"),
        ("noisy-mixed", 23, "spread", "alternate_fov"),
    ):
        case, matches, _observations = _inputs(name)
        initial = _saved_initial(case, matches, name)
        request = _subset(case, size, mode)
        if change == "bad_pick":
            # A deterministic single wrong correspondence on the peripheral
            # camera, with the correct picks in other views left untouched.
            picked = next(o for o in request["observations"] if o["match_id"] == "view_2")
            picked["u"] += 20.0
            picked["v"] -= 15.0
        if change == "alternate_fov":
            for c in request["cameras"]:
                c["fx"] *= 1.15
                c["fy"] *= 1.15
        label = f"{name}-{size}-{mode}-{change}"
        yield label, case, request, initial


def _saved_initial(case, matches, name):
    from match_perspective.core import sync as core_sync
    run = "run-02" if name == "no-vp-mixed-guessedK" else "run-03"
    rows = [json.loads(line) for line in (FROZEN / run / "sync-ledger.jsonl").read_text().splitlines()]
    attempt = next(row["attempt"] for row in rows
                   if row.get("kind") == "started" and row["label"] == name)
    record = next(row["result"] for row in rows
                  if row.get("kind") == "completed" and row["attempt"] == attempt)
    similarities = {}
    for item in matches:
        source = item.base_calibration
        world = record["cameras"][item.match_id]
        world_r = np.asarray(world["rotation"], float)
        world_c = np.asarray(world["center"], float)
        rotation = world_r.T @ source.rotation_w2c
        similarities[item.match_id] = core_sync.SimilarityTransform(
            1.0, rotation, world_c - rotation @ source.camera_center)
    return core_sync.SyncSolveResult(
        similarities=similarities,
        landmarks={key: np.asarray(value, float) for key, value in record["landmarks"].items()},
        mean_reprojection_px=record["reported_rmse_px"],
        per_match_rmse_px={}, per_landmark_rmse_px={}, message="Frozen fresh Sync start",
        success=record["success"])


def _run_fit(request, initial):
    cameras = request["cameras"]
    calibrations = {}
    for camera in cameras:
        k = geometry.CameraIntrinsics(camera["fx"], camera["fy"], camera["cx"],
                                      camera["cy"], camera["width"], camera["height"])
        calibrations[camera["id"]] = geometry.Calibration(
            k, np.asarray(camera["rotation"], float), np.asarray(camera["center"], float))
    observations = [sync.SyncObservation(**o) for o in request["observations"]]
    initial.landmarks = {key: value for key, value in initial.landmarks.items()
                         if key in {o.landmark_id for o in observations}}
    fitted = fit_independent_focals(calibrations, observations, initial,
                                   anchor_id=request["anchor_id"], pick_sigma_px=1.0)
    record = result_record(fitted.sync_result, [dict(c, fx=fitted.calibrations[c["id"]].intrinsics.fx,
                                                fy=fitted.calibrations[c["id"]].intrinsics.fy)
                                                 for c in cameras]) if fitted.accepted else dict(
        success=False, message=fitted.reason, cameras={}, landmarks={},
        reported_rmse_px=(fitted.fitted_rmse_px if np.isfinite(fitted.fitted_rmse_px) else None))
    return dict(accepted=fitted.accepted, reason=fitted.reason,
                fitted_rmse_px=(fitted.fitted_rmse_px if np.isfinite(fitted.fitted_rmse_px) else None),
                intervals_px=fitted.intervals_px, record=record)


def run(out):
    out.mkdir(parents=True, exist_ok=False)
    with tarfile.open(out / "source.tar.xz", "w:xz") as archive:
        for relative in SOURCES:
            archive.add(ROOT / relative, arcname=relative)
    metadata = dict(source_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
                                 for p in SOURCES}, environment=environment(ROOT),
                    saved_starts="independent-focal-production/run-03/sync-ledger.jsonl",
                    limits=dict(inner_sync_calls=0, bundle_attempts=14,
                                per_bundle_seconds=30, cumulative_bundle_seconds=300))
    (out / "source-runtime.json").write_text(json.dumps(metadata, indent=2) + "\n")
    with ExperimentBudget(out / "bundle-ledger.jsonl", metadata=metadata,
                          max_calls=14, per_call_seconds=30, wall_seconds=300) as budget:
        for label, case, request, initial in _trials():
            with budget.attempt(label, dict(request=request,
                                            initial=result_record(initial, case["request"]["cameras"]))) as attempt:
                fitted = _run_fit(request, initial)
                attempt.complete(fitted)
            # The independent oracle is deliberately downstream of the saved
            # decision. Trim its point requirement to the supplied subset.
            oracle = deepcopy(case)
            selected = {p["id"] for p in request["points"]}
            oracle["request"] = request
            oracle["truth"]["points"] = {k: v for k, v in oracle["truth"]["points"].items()
                                           if k in selected}
            oracle["expectation"]["required_points"] = sorted(selected)
            assessment = assess(oracle, fitted["record"])
            truth_fx = {c["id"]: c["fx"] for c in case["truth"]["cameras"]}
            interval_coverage = {k: low <= truth_fx[k] <= high
                                 for k, (low, high) in fitted["intervals_px"].items()}
            report = dict(label=label, assessment=assessment,
                          interval_coverage=interval_coverage)
            (out / f"{label}.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
            print(label, fitted["accepted"], fitted["reason"],
                  assessment["classification"], interval_coverage, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    run(args.out)


if __name__ == "__main__":
    main()
