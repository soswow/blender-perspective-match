"""Independent pinhole focal bundle adjustment for unconstrained point graphs.

The anchor camera and the first camera-baseline length fix the global similarity
gauge. All decisions use image picks and the fitted state; no scene truth enters.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
import time

import numpy as np

from . import geometry as core
from .sync import SyncObservation, SyncSolveResult, SimilarityTransform
from .sync.projection import _log_rodrigues, _rodrigues


FOCAL_SCALE_BOUNDS = (0.6, 1.6)
MAX_CAMERAS = 8
MAX_POINTS = 80
MAX_ITERATIONS = 100
MAX_SECONDS = 30.0


@dataclass
class FocalBundleOutcome:
    accepted: bool
    reason: str
    calibrations: dict[str, core.Calibration] = field(default_factory=dict)
    sync_result: SyncSolveResult | None = None
    intervals_px: dict[str, tuple[float, float]] = field(default_factory=dict)
    initial_rmse_px: float = float("inf")
    fitted_rmse_px: float = float("inf")


def _normalize_points(points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    center = points.mean(axis=0)
    spread = np.linalg.norm(points - center, axis=1).mean()
    if spread <= 1.0e-9:
        raise ValueError("Point picks have no image spread")
    scale = math.sqrt(2.0) / spread
    transform = np.array(((scale, 0.0, -scale * center[0]),
                          (0.0, scale, -scale * center[1]), (0.0, 0.0, 1.0)))
    return (points - center) * scale, transform


def _homography_forward_error(first: np.ndarray, second: np.ndarray,
                              sigma: float) -> float:
    """Return forward-transfer squared error whitened for noise in both images."""
    a, ta = _normalize_points(first)
    b, tb = _normalize_points(second)
    x, y = a.T
    u, v = b.T
    ones = np.ones(len(first))
    zeros = np.zeros(len(first))
    design = np.empty((2 * len(first), 9))
    design[0::2] = np.column_stack((-x, -y, -ones, zeros, zeros, zeros,
                                     u * x, u * y, u))
    design[1::2] = np.column_stack((zeros, zeros, zeros, -x, -y, -ones,
                                     v * x, v * y, v))
    _, _, vh = np.linalg.svd(design, full_matrices=False)
    h = np.linalg.solve(tb, vh[-1].reshape(3, 3) @ ta)
    mapped = (h @ np.column_stack((first, ones)).T).T
    if np.any(np.abs(mapped[:, 2]) < 1.0e-12):
        return float("inf")
    error = mapped[:, :2] / mapped[:, 2, None] - second
    whitened = 0.0
    for index in range(len(first)):
        denominator = mapped[index, 2]
        derivative = (h[:2, :2] - np.outer(mapped[index, :2] / denominator,
                                            h[2, :2])) / denominator
        covariance = sigma * sigma * (np.eye(2) + derivative @ derivative.T)
        whitened += float(error[index] @ np.linalg.solve(covariance, error[index]))
    return whitened


def _has_depth_evidence(ids: list[str], observations: list[SyncObservation],
                        sigma: float) -> bool:
    """Require one pair to reject a single homography at a 1% familywise bound."""
    picks: dict[str, dict[str, tuple[float, float]]] = {}
    for observation in observations:
        picks.setdefault(observation.landmark_id, {})[observation.match_id] = (
            observation.u, observation.v)
    pair_count = len(ids) * (len(ids) - 1) // 2
    # Laurent-Massart upper tail for chi-square, Bonferroni across pairs.
    # The transfer covariance propagates pick noise through each homography.
    # DLT is approximate; this conservative bound only accepts strong depth
    # evidence, not a fine statistical classification of near-planar scenes.
    log_inverse_alpha = math.log(100.0 * pair_count)
    strong_edges: dict[str, set[str]] = {camera_id: set() for camera_id in ids}
    for index, first in enumerate(ids):
        for second in ids[index + 1:]:
            common = [value for value in picks.values() if first in value and second in value]
            if len(common) < 5:
                continue
            first_uv = np.asarray([value[first] for value in common], float)
            second_uv = np.asarray([value[second] for value in common], float)
            try:
                squared = _homography_forward_error(first_uv, second_uv, sigma)
            except (ValueError, np.linalg.LinAlgError):
                continue
            dof = 2 * len(common) - 8
            threshold = dof + 2 * math.sqrt(dof * log_inverse_alpha) + 2 * log_inverse_alpha
            if squared > threshold:
                strong_edges[first].add(second)
                strong_edges[second].add(first)
    reached = {ids[0]}
    frontier = [ids[0]]
    while frontier:
        for neighbor in strong_edges[frontier.pop()]:
            if neighbor not in reached:
                reached.add(neighbor)
                frontier.append(neighbor)
    return reached == set(ids)


def fit_independent_focals(
    calibrations: dict[str, core.Calibration],
    observations: list[SyncObservation],
    initial: SyncSolveResult,
    *, anchor_id: str,
    pick_sigma_px: float = 1.0,
    cancel_check=None,
    progress_callback=None,
) -> FocalBundleOutcome:
    """Refine all free point focals, poses and 3D in one fixed anchor gauge."""
    def refuse(reason: str, *, fitted: float = float("inf")) -> FocalBundleOutcome:
        return FocalBundleOutcome(False, reason, initial_rmse_px=initial_rmse,
                                  fitted_rmse_px=fitted)

    initial_rmse = float("inf")
    ids = list(calibrations)
    if not (3 <= len(ids) <= MAX_CAMERAS):
        return refuse(f"Point focal estimation needs 3–{MAX_CAMERAS} cameras")
    if anchor_id not in calibrations:
        return refuse("Anchor camera is missing")
    ids.remove(anchor_id)
    ids.insert(0, anchor_id)
    if not np.isfinite(pick_sigma_px) or pick_sigma_px <= 0:
        return refuse("Pick sigma must be positive and finite")
    if not initial.success or set(initial.similarities) != set(ids):
        return refuse("Initial Sync must support every camera")
    point_ids = sorted({item.landmark_id for item in observations})
    if not (8 <= len(point_ids) <= MAX_POINTS) or set(initial.landmarks) != set(point_ids):
        return refuse(f"Point focal estimation needs 8–{MAX_POINTS} fully reconstructed points")
    if any(item.match_id not in calibrations or item.on_ground or
           not np.isfinite((item.u, item.v, item.weight)).all() or item.weight <= 0
           for item in observations):
        return refuse("Point picks must be finite, free and from included cameras")
    for calibration in calibrations.values():
        k = calibration.intrinsics
        if (not np.isfinite((k.fx, k.fy, k.cx, k.cy)).all() or k.fx <= 0 or
            not np.isclose(k.fx, k.fy, rtol=1.0e-6) or calibration.has_distortion):
            return refuse("Point focal estimation needs square pixels and zero distortion")
    if any(sum(item.landmark_id == point_id for item in observations) < 2
           for point_id in point_ids):
        return refuse("Every point needs at least two picks")
    if any(sum(item.match_id == camera_id for item in observations) < 8
           for camera_id in ids):
        return refuse("Every camera needs at least eight point picks")
    if not _has_depth_evidence(ids, observations, float(pick_sigma_px)):
        return refuse("Point picks are compatible with a homography; depth and independent FOV are ambiguous")

    anchor_cal = calibrations[anchor_id]
    anchor_sim = initial.similarities[anchor_id]
    if (abs(anchor_sim.scale - 1.0) > 1.0e-8 or
        np.linalg.norm(anchor_sim.rotation - np.eye(3)) > 1.0e-8 or
        np.linalg.norm(anchor_sim.translation) > 1.0e-8):
        return refuse("Initial anchor gauge is not fixed")
    global_centers = []
    global_rotations = []
    for camera_id in ids:
        cal = calibrations[camera_id]
        sim = initial.similarities[camera_id]
        if not np.isfinite(sim.scale) or sim.scale <= 0:
            return refuse("Initial camera scale is invalid")
        global_centers.append(sim.transform_point(cal.camera_center))
        global_rotations.append(cal.rotation_w2c @ sim.rotation.T)
    anchor_r = global_rotations[0]
    anchor_c = global_centers[0]
    baseline = float(np.linalg.norm(global_centers[1] - anchor_c))
    if not np.isfinite(baseline) or baseline < 1.0e-8:
        return refuse("Initial camera baseline is zero")
    centers0 = np.asarray([anchor_r @ (center - anchor_c) / baseline
                           for center in global_centers])
    rotations0 = [rotation @ anchor_r.T for rotation in global_rotations]
    points0 = np.asarray([anchor_r @ (initial.landmarks[key] - anchor_c) / baseline
                          for key in point_ids])
    direction = centers0[1] / np.linalg.norm(centers0[1])
    axis = np.eye(3)[np.argmin(np.abs(direction))]
    tangent_a = np.cross(direction, axis)
    tangent_a /= np.linalg.norm(tangent_a)
    tangent_b = np.cross(direction, tangent_a)
    tangents = np.vstack((tangent_a, tangent_b))
    ncam = len(ids)
    npoint = len(point_ids)
    point_offset = ncam + 5 + 6 * (ncam - 2)
    x = np.concatenate((np.zeros(ncam), _log_rodrigues(rotations0[1]),
                        np.zeros(2), *[np.concatenate((_log_rodrigues(rotations0[i]),
                                                      centers0[i])) for i in range(2, ncam)],
                        points0.ravel()))
    camera_index = {key: index for index, key in enumerate(ids)}
    point_index = {key: index for index, key in enumerate(point_ids)}
    ci = np.asarray([camera_index[item.match_id] for item in observations], int)
    pi = np.asarray([point_index[item.landmark_id] for item in observations], int)
    uv = np.asarray([(item.u, item.v) for item in observations], float)
    weights = np.sqrt(np.asarray([item.weight for item in observations], float))
    base_fx = np.asarray([calibrations[key].intrinsics.fx for key in ids], float)
    pp = np.asarray([(calibrations[key].intrinsics.cx, calibrations[key].intrinsics.cy)
                     for key in ids], float)
    lower, upper = np.log(FOCAL_SCALE_BOUNDS)
    start_time = time.monotonic()

    def decode(params: np.ndarray):
        focal = base_fx * np.exp(params[:ncam])
        raw = direction + params[ncam + 3] * tangents[0] + params[ncam + 4] * tangents[1]
        first_center = raw / np.linalg.norm(raw)
        rotations = [np.eye(3), _rodrigues(params[ncam:ncam + 3])]
        centers = [np.zeros(3), first_center]
        for camera in range(2, ncam):
            offset = ncam + 5 + 6 * (camera - 2)
            rotations.append(_rodrigues(params[offset:offset + 3]))
            centers.append(params[offset + 3:offset + 6])
        return focal, rotations, np.asarray(centers), params[point_offset:].reshape(npoint, 3)

    def residual_and_jacobian(params: np.ndarray, *, jacobian: bool):
        focal, rotations, centers, points = decode(params)
        residual = np.empty((len(uv), 2))
        jac = np.zeros((2 * len(uv), len(params))) if jacobian else None
        depths = np.empty(len(uv))
        for camera in range(ncam):
            selected = np.flatnonzero(ci == camera)
            if not len(selected):
                continue
            point = points[pi[selected]]
            offset_xyz = point - centers[camera]
            q = (rotations[camera] @ offset_xyz.T).T
            z = q[:, 2]
            depths[selected] = z
            safe_z = np.maximum(z, 1.0e-6)
            ratio = q[:, :2] / safe_z[:, None]
            predicted = focal[camera] * ratio + pp[camera]
            predicted += np.maximum(1.0e-6 - z, 0.0)[:, None] * 1.0e3
            residual[selected] = (predicted - uv[selected]) * weights[selected, None]
            if jac is None:
                continue
            dq = np.zeros((len(selected), 2, 3))
            dq[:, 0, 0] = focal[camera] / safe_z
            dq[:, 1, 1] = focal[camera] / safe_z
            dq[:, 0, 2] = -focal[camera] * q[:, 0] / safe_z**2
            dq[:, 1, 2] = -focal[camera] * q[:, 1] / safe_z**2
            dq[z <= 1.0e-6, :, 2] -= 1.0e3
            dq *= weights[selected, None, None]
            rows = np.column_stack((2 * selected, 2 * selected + 1)).ravel()
            jac[rows, camera] = (focal[camera] * ratio * weights[selected, None]).ravel()
            point_j = np.einsum('nij,jk->nik', dq, rotations[camera])
            for local, point_id in enumerate(pi[selected]):
                jac[2 * selected[local]:2 * selected[local] + 2,
                    point_offset + 3 * point_id:point_offset + 3 * point_id + 3] = point_j[local]
            if camera:
                if camera == 1:
                    rotation_start = ncam
                    center_j = []
                    raw = direction + params[ncam + 3] * tangents[0] + params[ncam + 4] * tangents[1]
                    norm = np.linalg.norm(raw)
                    unit = raw / norm
                    for tangent in tangents:
                        center_j.append((tangent - unit * (unit @ tangent)) / norm)
                    center_start = ncam + 3
                else:
                    rotation_start = ncam + 5 + 6 * (camera - 2)
                    center_j = np.eye(3)
                    center_start = rotation_start + 3
                jac[rows, center_start:center_start + len(center_j)] = (
                    -np.einsum('nij,kj->nik', point_j, np.asarray(center_j))).reshape(-1, len(center_j))
                for component in range(3):
                    trial = params[rotation_start:rotation_start + 3].copy()
                    step = 1.0e-6 * max(1.0, abs(trial[component]))
                    trial[component] += step
                    derivative = ((_rodrigues(trial) - rotations[camera]) @ offset_xyz.T).T / step
                    jac[rows, rotation_start + component] = np.einsum(
                        'nij,nj->ni', dq, derivative).ravel()
        return residual.ravel(), jac, depths

    try:
        initial_residual, _, _ = residual_and_jacobian(x, jacobian=False)
        initial_raw = initial_residual.reshape(-1, 2) / weights[:, None]
        initial_rmse = float(np.sqrt(np.mean(np.sum(initial_raw**2, axis=1))))
        damping = 1.0e-3
        converged = False
        iterations = 0
        for iteration in range(MAX_ITERATIONS):
            if cancel_check and cancel_check():
                return refuse("Cancelled")
            if time.monotonic() - start_time > MAX_SECONDS:
                return refuse("Point focal fit reached its time limit")
            if progress_callback:
                progress_callback(iteration, MAX_ITERATIONS, "Estimating focal from points")
            residual, jac, _ = residual_and_jacobian(x, jacobian=True)
            cost = float(residual @ residual)
            column_scale = np.maximum(np.linalg.norm(jac, axis=0), 1.0e-8)
            scaled = jac / column_scale
            gradient = scaled.T @ residual
            if np.linalg.norm(gradient, ord=np.inf) < 1.0e-7:
                converged = True
                iterations = iteration
                break
            accepted_step = False
            for _trial in range(12):
                # Augmented least squares is better conditioned than normal equations.
                system = np.vstack((scaled, math.sqrt(damping) * np.eye(len(x))))
                target = np.concatenate((-residual, np.zeros(len(x))))
                step_scaled = np.linalg.lstsq(system, target, rcond=None)[0]
                trial_x = x + step_scaled / column_scale
                trial_x[:ncam] = np.clip(trial_x[:ncam], lower, upper)
                trial_residual, _, _ = residual_and_jacobian(trial_x, jacobian=False)
                trial_cost = float(trial_residual @ trial_residual)
                if np.isfinite(trial_cost) and trial_cost < cost:
                    relative_gain = (cost - trial_cost) / max(cost, 1.0)
                    x = trial_x
                    damping = max(damping / 3.0, 1.0e-9)
                    accepted_step = True
                    if relative_gain < 1.0e-9:
                        converged = True
                    break
                damping *= 10.0
            iterations = iteration + 1
            if converged or not accepted_step:
                converged = converged or not accepted_step and np.linalg.norm(gradient, ord=np.inf) < 1.0e-5
                break
        if not converged:
            return refuse("Point focal fit did not converge")
        fitted_residual, jac, depths = residual_and_jacobian(x, jacobian=True)
        end_raw = fitted_residual.reshape(-1, 2) / weights[:, None]
        fitted_rmse = float(np.sqrt(np.mean(np.sum(end_raw**2, axis=1))))
        if not np.isfinite(fitted_rmse) or np.any(depths <= 0):
            return refuse("Fitted scene has points behind a camera", fitted=fitted_rmse)
        if np.any(x[:ncam] <= lower + 1.0e-4) or np.any(x[:ncam] >= upper - 1.0e-4):
            return refuse("Fitted focal reached a search bound", fitted=fitted_rmse)
        # Residual count and model dimensions make this a noise-aware fit test.
        degrees_freedom = max(2 * len(uv) - len(x), 1)
        expected = pick_sigma_px**2 * (degrees_freedom +
            2 * math.sqrt(degrees_freedom * math.log(100.0)) + 2 * math.log(100.0))
        if float(np.sum(end_raw**2)) > expected:
            return refuse("Point fit is inconsistent with the stated pick noise", fitted=fitted_rmse)
        # Reject serious camera-specific regression even if total cost improves.
        start_per_camera = initial_raw
        end_per_camera = end_raw
        for camera in range(ncam):
            chosen = ci == camera
            start_sse = float(np.sum(start_per_camera[chosen]**2))
            end_sse = float(np.sum(end_per_camera[chosen]**2))
            slack = pick_sigma_px**2 * (2 * len(start_per_camera[chosen]) +
                2 * math.sqrt(2 * len(start_per_camera[chosen]) * math.log(100.0)) +
                2 * math.log(100.0))
            if end_sse > start_sse + slack:
                return refuse("A camera's point fit deteriorated", fitted=fitted_rmse)
        # Local covariance after fixing anchor and baseline gauges. Report
        # unbounded focal directions rather than mistaking a pseudoinverse for
        # evidence when the scene is rank deficient.
        column_scale = np.maximum(np.linalg.norm(jac, axis=0), 1.0e-8)
        u, singular, vh = np.linalg.svd(jac / column_scale, full_matrices=False)
        tolerance = np.finfo(float).eps * max(jac.shape) * singular[0]
        null = singular <= tolerance
        if jac.shape[0] < jac.shape[1]:
            return refuse("Too few point observations for independent focal estimation", fitted=fitted_rmse)
        focal, rotations, centers, points = decode(x)
        intervals = {}
        for camera, camera_id in enumerate(ids):
            if np.any(np.abs(vh[null, camera]) > 1.0e-6):
                return refuse("Focal uncertainty is unbounded", fitted=fitted_rmse)
            # Weighted fitting with homoscedastic raw pixel noise uses sandwich
            # covariance. Sync weights change the estimator, not the noise of
            # an independent click: influence = (W^1/2 J)^+ W^1/2.
            influence = ((vh[~null, camera] / singular[~null]) @
                         u[:, ~null].T) * np.repeat(weights, 2) / column_scale[camera]
            sigma_log = pick_sigma_px * np.linalg.norm(influence)
            if not np.isfinite(sigma_log) or sigma_log >= 10:
                return refuse("Focal uncertainty is unbounded", fitted=fitted_rmse)
            intervals[camera_id] = (float(focal[camera] * math.exp(-1.96 * sigma_log)),
                                    float(focal[camera] * math.exp(1.96 * sigma_log)))
        # Preserve private poses; the fitted world poses go into the existing
        # root similarities, and points return to the original anchor world.
        result_sims = {anchor_id: SimilarityTransform()}
        result_cals = {}
        result_points = {point_ids[index]: anchor_r.T @ (point * baseline) + anchor_c
                         for index, point in enumerate(points)}
        for camera, camera_id in enumerate(ids):
            source = calibrations[camera_id]
            source_k = source.intrinsics
            result_cals[camera_id] = core.Calibration(
                intrinsics=core.CameraIntrinsics(float(focal[camera]), float(focal[camera]),
                                                 source_k.cx, source_k.cy,
                                                 source_k.image_width, source_k.image_height),
                rotation_w2c=np.array(source.rotation_w2c, copy=True),
                camera_center=np.array(source.camera_center, copy=True),
                division_lambda=0.0, brown_conrady=())
            if camera == 0:
                continue
            global_rotation = rotations[camera] @ anchor_r
            global_center = anchor_r.T @ (centers[camera] * baseline) + anchor_c
            sim_rotation = global_rotation.T @ source.rotation_w2c
            old_scale = float(initial.similarities[camera_id].scale)
            result_sims[camera_id] = SimilarityTransform(
                scale=old_scale, rotation=sim_rotation,
                translation=global_center - old_scale * (sim_rotation @ source.camera_center))
        per_camera = {}
        for camera, camera_id in enumerate(ids):
            chosen = ci == camera
            per_camera[camera_id] = float(np.sqrt(np.mean(np.sum(end_per_camera[chosen]**2, axis=1))))
        per_point = {}
        for point, point_id in enumerate(point_ids):
            chosen = pi == point
            per_point[point_id] = float(np.sqrt(np.mean(np.sum(end_per_camera[chosen]**2, axis=1))))
        sync_result = SyncSolveResult(
            similarities=result_sims, landmarks=result_points,
            mean_reprojection_px=fitted_rmse, per_match_rmse_px=per_camera,
            per_landmark_rmse_px=per_point,
            message=f"Independent point focals fitted in {iterations} iterations",
            bundle_adjusted=True)
        return FocalBundleOutcome(True, "", result_cals, sync_result, intervals,
                                  initial_rmse, fitted_rmse)
    except (FloatingPointError, ValueError, np.linalg.LinAlgError) as exc:
        return refuse(f"Point focal fit failed: {exc}")
